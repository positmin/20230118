from django.urls import path

from customer import views

app_name = 'customer'

urlpatterns = [
    path('', views.CustomerList.as_view(), name='customer_list'),
    path('form', views.CustomerCreate.as_view(), name='customer_form'),
    path('edit/<str:pk>', views.CustomerUpdate.as_view(), name='customer_edit'),
    path('detail/<str:pk>', views.CustomerDetail.as_view(), name='customer_detail'),
    path('delete/<str:pk>', views.CustomerDelete.as_view(), name='customer_delete'),
    path('storePopup', views.StorePopupList.as_view(), name='store_popup_list'),
    path('SvdRecommend', views.SvdRecommend.as_view(), name='svd_recommend'),

    path('deliveryAddress', views.DeliveryAddressList.as_view(), name='delivery_address_list'),
    path('deliveryAddressForm', views.DeliveryAddressCreate.as_view(), name='delivery_address_form'),
    path('deliveryAddressEdit/<str:pk>', views.DeliveryAddressUpdate.as_view(), name='delivery_address_edit'),
    path('deliveryAddressDetail/<str:pk>', views.DeliveryAddressDetail.as_view(), name='delivery_address_detail'),
    path('deliveryAddressDelete/<str:pk>', views.DeliveryAddressDelete.as_view(), name='delivery_address_delete'),
    path('customerPopup', views.CustomerPopupList.as_view(), name='customer_popup_list'),
    path('search_sigungu', views.search_sigungu, name='search_sigungu'),
]
