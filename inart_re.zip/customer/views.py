from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.forms import forms

from django.views.generic import TemplateView, ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from common.models import CommonCode
from .models import Customer, DeliveryAddress
from .models import Store


class CustomerList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer

    def get_context_data(self, **kwargs):
        context = super(CustomerList, self).get_context_data(**kwargs)

        context['commoncode'] = CommonCode.objects.all().filter(g_cd_id='C101')

        return context


class CustomerCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer
    success_url = reverse_lazy('customer:customer_list')
    fields = ['cust_nm', 'gender', 'birth', 'phone1', 'phone2', 'phone3', 'email1', 'email2', 'sns_agr', 'cust_class',
              'regist_dt', 'store_no']

    def get_context_data(self, **kwargs):
        context = super(CustomerCreate, self).get_context_data(**kwargs)

        context['cust_class_list'] = CommonCode.objects.filter(g_cd_id='C101')
        context['email_list'] = CommonCode.objects.filter(g_cd_id='EMAIL')
        context['phone_list'] = CommonCode.objects.filter(g_cd_id='PHONE')

        return context


class CustomerUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer
    success_url = reverse_lazy('customer:customer_list')
    fields = ['cust_nm', 'gender', 'birth', 'phone1', 'phone2', 'phone3', 'email1', 'email2', 'sns_agr', 'cust_class',
              'regist_dt', 'store_no']

    def get_context_data(self, **kwargs):
        context = super(CustomerUpdate, self).get_context_data(**kwargs)

        context['cust_class_list'] = CommonCode.objects.filter(g_cd_id='C101')
        context['email_list'] = CommonCode.objects.filter(g_cd_id='EMAIL')
        context['phone_list'] = CommonCode.objects.filter(g_cd_id='PHONE')

        return context


class CustomerDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer
    fields = ['cust_nm', 'gender', 'birth', 'phone1', 'phone2', 'phone3', 'email1', 'email2', 'sns_agr', 'cust_class',
              'regist_dt', 'store_no']

    def get_context_data(self, **kwargs):
        context = super(CustomerDetail, self).get_context_data(**kwargs)

        context['cust_class_list'] = CommonCode.objects.filter(g_cd_id='C101')
        context['email_list'] = CommonCode.objects.filter(g_cd_id='EMAIL')
        context['phone_list'] = CommonCode.objects.filter(g_cd_id='PHONE')

        return context


class CustomerDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer
    success_url = reverse_lazy('customer:customer_list')


class StorePopupList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Store
    template_name = 'customer/storepopup_list.html'

    def get_context_data(self, **kwargs):
        context = super(StorePopupList, self).get_context_data(**kwargs)

        context['area'] = CommonCode.objects.filter(g_cd_id='SAREA')
        context['store_tp'] = CommonCode.objects.filter(g_cd_id='STSTP')

        return context


class SvdRecommend(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer
    template_name = 'customer/customer_recommend.html'

    def get_context_data(self, **kwargs):
        context = super(SvdRecommend, self).get_context_data(**kwargs)

        svd = svd_recommend()
        context['name'] = svd['고객명']
        context['sales'] = svd['실제 구매 상품']
        context['recommend'] = svd['추천 상품']

        return context


def svd_recommend():
    import datetime
    import pandas as pd
    import numpy as np

    df = pd.read_csv("F:/inart_re/templates/excel_data/svd_recommend.csv", encoding="cp949")

    df['매출일'] = pd.to_datetime(df['매출일'], format="%Y/%m/%d")

    df['date'] = df['매출일'].dt.date
    df_year_round = df[df['date'] < datetime.date(2016, 6, 30)]
    df_year_end = df[df['date'] > datetime.date(2016, 6, 30)]

    customer_item_round_set = df_year_round.groupby('받는사람')['품목ID'].apply(set)

    customer_item_dict = {}

    for customer_id, stocks in customer_item_round_set.items():
        customer_item_dict[customer_id] = {}
        for stock_code in stocks:
            customer_item_dict[customer_id][stock_code] = 'old'

    customer_item_end_set = df_year_end.groupby('받는사람')['품목ID'].apply(set)

    for customer_id, stocks in customer_item_end_set.items():
        if customer_id in customer_item_dict:
            for stock_code in stocks:
                if stock_code in customer_item_dict[customer_id]:
                    customer_item_dict[customer_id][stock_code] = 'both'
                else:
                    customer_item_dict[customer_id][stock_code] = 'new'

        else:
            customer_item_dict[customer_id] = {}
            for stock_code in stocks:
                customer_item_dict[customer_id][stock_code] = 'new'

    columns = ['customerID', 'old', 'new', 'both']
    df_order_info = pd.DataFrame(columns=columns)

    for customer_id in customer_item_dict:
        old = 0
        new = 0
        both = 0

        for stock_code in customer_item_dict[customer_id]:
            status = customer_item_dict[customer_id][stock_code]
            if status == 'old':
                old += 1
            elif status == 'new':
                new += 1
            else:
                both += 1

        row = [customer_id, old, new, both]
        series = pd.Series(row, index=columns)
        df_order_info = df_order_info.append(series, ignore_index=True)

    uir_df = df_year_round.groupby(['받는사람', '품목ID'])['주문번호'].nunique().reset_index()

    uir_df['rating'] = uir_df['주문번호'].apply(lambda x: np.log10(x) + 1)
    uir_df['rating'] = ((uir_df['rating'] - uir_df['rating'].min()) /
                        (uir_df['rating'].max() - uir_df['rating'].min()) * 4) + 1

    uir_df = uir_df[['받는사람', '품목ID', 'rating']]

    import time
    from surprise import SVD, Dataset, Reader, accuracy
    from surprise.model_selection import train_test_split

    reader = Reader(rating_scale=(1, 5))
    data = Dataset.load_from_df(uir_df[['받는사람', '품목ID', 'rating']], reader)
    train_data, test_data = train_test_split(data, test_size=0.2)

    train_start = time.time()

    model = SVD(n_factors=8, lr_all=0.005, reg_all=0.02, n_epochs=200)
    model.fit(train_data)
    train_end = time.time()

    predictions = model.test(test_data)

    accuracy.rmse(predictions)

    reader = Reader(rating_scale=(1, 5))
    data = Dataset.load_from_df(uir_df[['받는사람', '품목ID', 'rating']], reader)
    train_data = data.build_full_trainset()

    train_start = time.time()

    model = SVD(n_factors=8, lr_all=0.005, reg_all=0.02, n_epochs=200)
    model.fit(train_data)
    train_end = time.time()

    test_data = train_data.build_anti_testset()
    target_user_predictions = model.test(test_data)

    new_order_prediction_dict = {}

    for customer_id, stock_code, _, predicted_rating, _ in target_user_predictions:
        if customer_id in new_order_prediction_dict:
            if stock_code in new_order_prediction_dict[customer_id]:
                pass
            else:
                new_order_prediction_dict[customer_id][stock_code] = predicted_rating
        else:
            new_order_prediction_dict[customer_id] = {}
            new_order_prediction_dict[customer_id][stock_code] = predicted_rating

    test_data = train_data.build_testset()
    target_user_predictions = model.test(test_data)

    reorder_prediction_dict = {}

    for customer_id, stock_code, _, predicted_rating, _ in target_user_predictions:
        if customer_id in reorder_prediction_dict:
            if stock_code in reorder_prediction_dict[customer_id]:
                pass
            else:
                reorder_prediction_dict[customer_id][stock_code] = predicted_rating
        else:
            reorder_prediction_dict[customer_id] = {}
            reorder_prediction_dict[customer_id][stock_code] = predicted_rating

    total_prediction_dict = {}

    for customer_id in new_order_prediction_dict:
        if customer_id not in total_prediction_dict:
            total_prediction_dict[customer_id] = {}
        for stock_code, predicted_rating in new_order_prediction_dict[customer_id].items():
            if stock_code not in total_prediction_dict[customer_id]:
                total_prediction_dict[customer_id][stock_code] = predicted_rating

    for customer_id in reorder_prediction_dict:
        if customer_id not in total_prediction_dict:
            total_prediction_dict[customer_id] = {}
        for stock_code, predicted_rating in reorder_prediction_dict[customer_id].items():
            if stock_code not in total_prediction_dict[customer_id]:
                total_prediction_dict[customer_id][stock_code] = predicted_rating

    simulation_test_df = df_year_end.groupby('받는사람')['품목ID'].apply(set).reset_index()
    simulation_test_df.columns = ['받는사람', 'RealOrdered']
    simulation_test_df.head()

    simulation_test_df['PredictedOrder(New)'] = simulation_test_df['받는사람']. \
        apply(lambda x: add_predicted_stock_set(x, new_order_prediction_dict))
    simulation_test_df['PredictedOrder(Reorder)'] = simulation_test_df['받는사람']. \
        apply(lambda x: add_predicted_stock_set(x, reorder_prediction_dict))
    simulation_test_df['PredictedOrder(Total)'] = simulation_test_df['받는사람']. \
        apply(lambda x: add_predicted_stock_set(x, total_prediction_dict))
    simulation_test_df

    # 시뮬레이션 대상 유저에게 상품을 추천해준 결과를 평가합니다.
    simulation_test_df['top_k_recall(Reorder)'] = simulation_test_df.apply(lambda x: calculate_recall(x['RealOrdered'], x['PredictedOrder(Reorder)'], 5), axis=1)
    simulation_test_df['top_k_recall(New)'] = simulation_test_df.apply(lambda x: calculate_recall(x['RealOrdered'],
                                         x['PredictedOrder(New)'],
                                         5), axis=1)
    simulation_test_df['top_k_recall(Total)'] = simulation_test_df.apply(lambda x: calculate_recall(x['RealOrdered'],
                                         x['PredictedOrder(Total)'],
                                         5), axis=1)

    k = 5
    result_df = simulation_test_df[simulation_test_df['PredictedOrder(Reorder)'].notnull()]
    result_df['PredictedOrder(Reorder)'] = result_df['PredictedOrder(Reorder)'].apply(lambda x: x[:k])
    result_df = result_df[['받는사람', 'RealOrdered', 'PredictedOrder(Reorder)', 'top_k_recall(Reorder)']]

    result_df = result_df.rename(columns={'받는사람': '고객명'})
    result_df = result_df.rename(columns={'RealOrdered': '실제 구매 상품'})
    result_df = result_df.rename(columns={'PredictedOrder(Reorder)': '추천 상품'})
    result_df = result_df.rename(columns={'top_k_recall(Reorder)': 'recall'})

    not_recall = result_df['recall'] != 1.0
    subset_df = result_df[not_recall]

    dataframe = subset_df.nlargest(10, 'recall')

    return dataframe


# 구매 예측의 상위 k개의 recall(재현율)을 평가 기준으로 정의합니다.
def calculate_recall(real_order, predicted_order, k):
    # 만약 추천 대상 상품이 없다면, 11월 이후에 상품을 처음 구매하는 유저입니다.
    if predicted_order is None:
        return None

    # SVD 모델에서 현재 유저의 Rating이 높은 상위 k개의 상품을 "구매 할 것으로 예측"합니다.
    predicted = predicted_order[:k]
    true_positive = 0
    for stock_code in predicted:
        if stock_code in real_order:
            true_positive += 1

    # 예측한 상품 중, 실제로 유저가 구매한 상품의 비율(recall)을 계산합니다.
    recall = true_positive / len(predicted)
    return recall


def add_predicted_stock_set(customer_id, prediction_dict):
    if customer_id in prediction_dict:
        predicted_stock_dict = prediction_dict[customer_id]
        sorted_stocks = sorted(predicted_stock_dict, key=lambda x: predicted_stock_dict[x], reverse=True)
        return sorted_stocks
    else:
        return None


class DeliveryAddressList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = DeliveryAddress

    def get_context_data(self, **kwargs):
        context = super(DeliveryAddressList, self).get_context_data(**kwargs)

        context['sig_cd_list'] = CommonCode.objects.filter(g_cd_id='SIDO')
        context['cpt_cd_list'] = CommonCode.objects.filter(g_cd_id='SIGUN')

        return context


class DeliveryAddressCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = DeliveryAddress
    success_url = reverse_lazy('customer:delivery_address_list')
    fields = ['da_nm', 'sig_cd', 'cpt_cd', 'addr1', 'addr2', 'zip_cd', 'cust_no']

    def get_context_data(self, **kwargs):
        context = super(DeliveryAddressCreate, self).get_context_data(**kwargs)

        context['sig_cd_list'] = CommonCode.objects.filter(g_cd_id='SIDO')

        return context


class DeliveryAddressUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = DeliveryAddress
    success_url = reverse_lazy('customer:delivery_address_list')
    fields = ['da_nm', 'sig_cd', 'cpt_cd', 'addr1', 'addr2', 'zip_cd', 'cust_no']

    def get_context_data(self, **kwargs):
        context = super(DeliveryAddressUpdate, self).get_context_data(**kwargs)

        context['sig_cd_list'] = CommonCode.objects.filter(g_cd_id='SIDO')
        context['cpt_cd_list'] = CommonCode.objects.filter(g_cd_id='SIGUN', up_cd_id=self.get_object().sig_cd)

        return context


def search_sigungu(request):

    sig_cd = request.GET.get('sig_cd')

    sigungu_cd = CommonCode.objects.filter(g_cd_id='SIGUN', up_cd_id=sig_cd)
    data = list(sigungu_cd.values())

    context = {'sigungu': data}

    return JsonResponse(context)


class DeliveryAddressDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = DeliveryAddress
    fields = ['da_nm', 'sig_cd', 'cpt_cd', 'addr1', 'addr2', 'zip_cd', 'cust_no']

    def get_context_data(self, **kwargs):
        context = super(DeliveryAddressDetail, self).get_context_data(**kwargs)

        context['sig_cd_list'] = CommonCode.objects.filter(g_cd_id='SIDO')
        context['cpt_cd_list'] = CommonCode.objects.filter(g_cd_id='SIGUN', up_cd_id=self.get_object().sig_cd)

        return context


class DeliveryAddressDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = DeliveryAddress
    success_url = reverse_lazy('customer:delivery_address_list')


class CustomerPopupList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer
    template_name = 'customer/customerpopup_list.html'
