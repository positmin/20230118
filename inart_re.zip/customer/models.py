from django.contrib.auth.models import User
from django.db import models
from django.utils.timezone import now

from store.models import Store


class Customer(models.Model):
    cust_nm = models.CharField(db_column='cust_nm', max_length=20, default='')
    gender = models.CharField(db_column='gender', max_length=1, default='')
    birth = models.DateTimeField(db_column='birth', default='')
    phone1 = models.CharField(db_column='phone1', default='', max_length=4)
    phone2 = models.CharField(db_column='phone2', default='', max_length=4, null=True)
    phone3 = models.CharField(db_column='phone3', default='', max_length=4, null=True)
    email1 = models.CharField(db_column='email1', max_length=20, default='', null=True)
    email2 = models.CharField(db_column='email2', max_length=50, default='', null=True)
    sns_agr = models.CharField(db_column='sns_agr', max_length=1, default='', null=True)
    cust_class = models.CharField(db_column='cust_class', max_length=20, default='', null=True)
    regist_dt = models.DateTimeField(db_column='regist_dt', default='')
    store_no = models.ForeignKey(Store, db_column='store_no', on_delete=models.CASCADE, null=True, default='')

    class Meta:
        db_table = 'customer'


class DeliveryAddress(models.Model):
    da_nm = models.CharField(db_column='da_nm', max_length=20, default='')
    sig_cd = models.CharField(db_column='sig_cd', max_length=5, default='')
    cpt_cd = models.CharField(db_column='cpt_cd', max_length=5, default='')
    addr1 = models.CharField(db_column='addr1', max_length=100, default='')
    addr2 = models.CharField(db_column='addr2', max_length=100, default='')
    zip_cd = models.CharField(db_column='zip_cd', max_length=6, default='')
    cust_no = models.ForeignKey(Customer, db_column='cust_no', on_delete=models.CASCADE, default='')

    class Meta:
        db_table = 'delivery_address'


class Point(models.Model):
    point = models.IntegerField(db_column='point', default=0)
    update_dt = models.DateTimeField(db_column='update_dt', default=now)
    cust_no = models.ForeignKey(Customer, db_column='cust_no', on_delete=models.CASCADE)

    class Meta:
        db_table = 'point'


class As(models.Model):
    as_dt = models.DateTimeField(db_column='as_dt', default=now)
    as_app = models.CharField(db_column='as_app', max_length=10, default='')
    as_con = models.CharField(db_column='as_con', max_length=20, default='')
    as_info = models.CharField(db_column='as_info', max_length=20, default='')
    as_note = models.CharField(db_column='as_note', max_length=200, default='')
    cust_no = models.ForeignKey(Customer, db_column='cust_no', on_delete=models.CASCADE)

    class Meta:
        db_table = 'as'
