from django.db import models


class Store(models.Model):

    store_nm = models.CharField(db_column='store_nm', max_length=20, default='')
    store_tp = models.CharField(db_column='store_tp', max_length=10, default='')
    area = models.CharField(db_column='area', max_length=10, default='')
    workplace = models.CharField(db_column='workplace', max_length=20, default='')
    bu_day = models.IntegerField(db_column='bu_day', default=0)

    class Meta:
        db_table = 'store'
