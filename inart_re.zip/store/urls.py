from django.urls import path

from store import views

app_name = 'store'

urlpatterns = [
    path('', views.StoreList.as_view(), name='store_list'),
    path('detail/<int:pk>', views.StoreDetail.as_view(), name='store_detail'),
    path('form', views.StoreCreate.as_view(), name='store_form'),
    path('edit/<int:pk>)', views.StoreUpdate.as_view(), name='store_edit'),
    path('delete/<int:pk>)', views.StoreDelete.as_view(), name='store_delete'),

]
