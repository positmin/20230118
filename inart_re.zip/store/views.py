from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from common.models import CommonCode
from store.models import Store


class StoreList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Store

    def get_context_data(self, **kwargs):
        context = super(StoreList, self).get_context_data(**kwargs)

        context['store_tp_list'] = CommonCode.objects.filter(g_cd_id='STSTP')
        context['area_list'] = CommonCode.objects.filter(g_cd_id='SAREA')

        return context


class StoreDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Store
    fields = ['store_nm', 'store_tp', 'area', 'workplace', 'bu_day']

    def get_context_data(self, **kwargs):
        context = super(StoreDetail, self).get_context_data(**kwargs)

        context['store_tp_list'] = CommonCode.objects.filter(g_cd_id='STSTP')
        context['area_list'] = CommonCode.objects.filter(g_cd_id='SAREA')

        return context


class StoreCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Store
    success_url = reverse_lazy('store:store_list')
    fields = ['store_nm', 'store_tp', 'area', 'workplace', 'bu_day']


class StoreUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Store
    success_url = reverse_lazy('store:store_list')
    fields = ['store_nm', 'store_tp', 'area', 'workplace', 'bu_day']


class StoreDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Store
    success_url = reverse_lazy('store:store_list')
    fields = ['store_nm', 'store_tp', 'area', 'workplace', 'bu_day']
