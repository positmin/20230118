from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from product.models import Product
from common.models import CommonCode


class ProductList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Product


class ProductCodePopupList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    template_name = 'product/product_code_popup_list.html'
    context_object_name = 'commoncode'

    def get_queryset(self):
        return CommonCode.objects.filter(g_cd_id='PDIVS')


class ProductDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Product
    fields = ['pd_nm', 'pd_size', 'pd_color', 'pd_sto', 'pd_retprice', 'pd_cosprice', 'pd_origin', 'pd_barcode', 'cd_id']


class ProductCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Product
    success_url = reverse_lazy('product:product_list')
    fields = ['pd_nm', 'pd_size', 'pd_color', 'pd_sto', 'pd_retprice', 'pd_cosprice', 'pd_origin', 'pd_barcode', 'cd_id']


class ProductUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Product
    success_url = reverse_lazy('product:product_list')
    fields = ['pd_nm', 'pd_size', 'pd_color', 'pd_sto', 'pd_retprice', 'pd_cosprice', 'pd_origin', 'pd_barcode', 'cd_id']


class ProductDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Product
    success_url = reverse_lazy('product:product_list')
