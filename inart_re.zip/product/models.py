from django.db import models
from django.utils.timezone import now

from common.models import CommonCode
from customer.models import Customer, DeliveryAddress
from store.models import Store


class Product(models.Model):
    pd_nm = models.CharField(db_column='pd_nm', max_length=50, default='')
    pd_size = models.CharField(db_column='pd_size', max_length=20, default='')
    pd_color = models.CharField(db_column='pd_color', max_length=20, default='')
    pd_sto = models.CharField(db_column='pd_sto', max_length=20, default='')
    pd_retprice = models.IntegerField(db_column='pd_retprice', default=0)
    pd_cosprice = models.IntegerField(db_column='pd_cosprice', default=0)
    pd_origin = models.CharField(db_column='pd_origin', max_length=20, default='')
    pd_barcode = models.CharField(db_column='pd_barcode', max_length=20, default='')
    cd_id = models.ForeignKey(CommonCode, db_column='cd_id', on_delete=models.CASCADE, default='')
    register_id = models.CharField(db_column='register_id', max_length=20, default='anonymous')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)

    class Meta:
        db_table = 'product'


class Stock(models.Model):
    sto_plus_dt = models.DateTimeField(db_column='sto_plus_dt', default=now)
    sto_minus_dt = models.DateTimeField(db_column='sto_minus_dt', default=now)
    sto_quantity = models.IntegerField(db_column='sto_quantity', default=0)
    store_no = models.ForeignKey(Store, db_column='store_no', on_delete=models.CASCADE)
    pd_no = models.ForeignKey(Product, db_column='pd_no', on_delete=models.CASCADE)
    register_id = models.CharField(db_column='register_id', max_length=20, default='anonymous')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)

    class Meta:
        db_table = 'stock'


class ProductImage(models.Model):
    file_nm = models.CharField(db_column='file_nm', max_length=100, default='')
    file_path = models.CharField(db_column='file_path', max_length=200, default='')
    file_ext = models.CharField(db_column='file_ext', max_length=5, default='')
    file_size = models.IntegerField(db_column='file_size', default=0)
    pd_no = models.ForeignKey(Product, db_column='pd_no', on_delete=models.CASCADE)
    register_id = models.CharField(db_column='register_id', max_length=20, default='anonymous')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)

    class Meta:
        db_table = 'product_image'


class Review(models.Model):
    re_content = models.CharField(db_column='re_content', max_length=500, default='')
    re_rating = models.FloatField(db_column='re_rating', default=0.0)
    re_click = models.IntegerField(db_column='re_click', default=0)
    cust_no = models.ForeignKey(Customer, db_column='cust_no', on_delete=models.CASCADE)
    pd_no = models.ForeignKey(Product, db_column='pd_no', on_delete=models.CASCADE)
    register_id = models.CharField(db_column='register_id', max_length=20, default='anonymous')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)

    class Meta:
        db_table = 'review'


class Delivery(models.Model):
    de_rec_dt = models.DateTimeField(db_column='de_rec_dt', default=now)
    de_sch_dt = models.DateTimeField(db_column='de_sch_dt', default=now)
    de_dt = models.DateTimeField(db_column='de_dt', default=now)
    de_pro = models.CharField(db_column='de_pro', max_length=5, default='')
    da_no = models.ForeignKey(DeliveryAddress, db_column='da_no', on_delete=models.CASCADE)
    pd_no = models.ForeignKey(Product, db_column='pd_no', on_delete=models.CASCADE)
    register_id = models.CharField(db_column='register_id', max_length=20, default='anonymous')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)

    class Meta:
        db_table = 'delivery'
