from django.urls import path
from product import views

app_name = 'product'

urlpatterns = [
    path('', views.ProductList.as_view(), name='product_list'),
    path('detail/<str:pk>', views.ProductDetail.as_view(), name='product_detail'),
    path('form', views.ProductCreate.as_view(), name='product_form'),
    path('edit/<str:pk>)', views.ProductUpdate.as_view(), name='product_edit'),
    path('delete/<str:pk>)', views.ProductDelete.as_view(), name='product_delete'),
    path('popup', views.ProductCodePopupList.as_view(), name='product_code_popup_list'),
]