from django.urls import path

from orderlist import views

app_name = 'orderlist'

urlpatterns = [
    path('', views.OrderlistList.as_view(), name='orderlist_list'),
    path('detail/<int:pk>', views.OrderlistDetail.as_view(), name='orderlist_detail'),
    path('form', views.OrderlistCreate.as_view(), name='orderlist_form'),
    path('edit/<int:pk>)', views.OrderlistUpdate.as_view(), name='orderlist_edit'),
    path('delete/<int:pk>)', views.OrderlistDelete.as_view(), name='orderlist_delete'),
    path('orderPopup', views.OrderPopup.as_view(), name='order_popup'),
    path('productPopup', views.ProductPopup.as_view(), name='product_popup'),

]
