from django.db import models

from django.utils.timezone import now

from order.models import Order
from product.models import Product


class Orderlist(models.Model):
    price = models.IntegerField(db_column='price', default=0)
    dis_price = models.IntegerField(db_column='dis_price', default=0)
    quantity = models.IntegerField(db_column='quantity', default=0)
    note = models.CharField(db_column='note', max_length=200, default='')
    od_no = models.ForeignKey(Order, db_column='od_no', on_delete=models.CASCADE)
    pd_no = models.ForeignKey(Product, db_column='pd_no', on_delete=models.CASCADE)
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)
    register_id = models.CharField(db_column='register_id', max_length=10, default='anonymous')

    class Meta:
        db_table = 'orderlist'
