from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy


from orderlist.models import Orderlist
from order.models import Order
from product.models import Product


class OrderlistList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Orderlist


class OrderlistDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Orderlist
    fields = ['price', 'dis_price', 'quantity', 'note', 'od_no', 'pd_no']


class OrderlistCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Orderlist
    success_url = reverse_lazy('orderlist:orderlist_list')
    fields = ['price', 'dis_price', 'quantity', 'note', 'od_no', 'pd_no']


class OrderlistUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Orderlist
    success_url = reverse_lazy('orderlist:orderlist_list')
    fields = ['price', 'dis_price', 'quantity', 'note', 'od_no', 'pd_no']


class OrderlistDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Orderlist
    success_url = reverse_lazy('orderlist:orderlist_list')
    fields = ['price', 'dis_price', 'quantity', 'note', 'od_no', 'pd_no']


class OrderPopup(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Order
    template_name = 'orderlist/order_popup.html'


class ProductPopup(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Product
    template_name = 'orderlist/product_popup.html'
