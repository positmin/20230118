from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView
from django.urls import path, include
from inart import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path("", views.HomeView.as_view(), name='index'),
    path("admin/", admin.site.urls),
    path('login/', LoginView.as_view(template_name='login.html'), name="login"),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('loginForm/', views.AccountCreateView.as_view(), name='login_form'),
    path("common/", include('common.urls')),
    path("customer/", include('customer.urls')),
    path("store/", include('store.urls')),
    path("product/", include('product.urls')),
    path("order/", include('order.urls')),
    path("orderlist/", include('orderlist.urls')),
    path('monthlySalesChart/', views.monthly_sales_chart, name='monthly_sales_chart'),
    path('brandSalesChart/', views.brand_sales_chart, name='brand_sales_chart'),
]

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
