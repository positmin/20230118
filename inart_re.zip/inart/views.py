from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.urls import reverse_lazy
from django.views.generic import TemplateView, CreateView

from common.models import CommonCode
from order.models import Order
from product.models import Product
from store.models import Store

from datetime import datetime
from dateutil.relativedelta import relativedelta

from orderlist.models import Orderlist


class HomeView(LoginRequiredMixin, TemplateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    template_name = "index.html"

    def get_context_data(self, **kwargs):
        context = super(HomeView, self).get_context_data(**kwargs)

        today = datetime.today()

        # 날짜 받아오기
        date_dict = get_req_date(today)

        store_tp_obj = CommonCode.objects.filter(g_cd_id='STSTP')
        pdivl_obj = CommonCode.objects.values_list('cd_id', 'cd_nm').filter(g_cd_id='PDIVL')

        last_month_list = calc_sales_data(date_dict['lm_start'], date_dict['lm_end'], store_tp_obj)
        last_year_last_month_list = calc_sales_data(date_dict['lylm_start'], date_dict['lylm_end'], store_tp_obj)
        this_month_list = calc_sales_data(date_dict['tm_start'], date_dict['tm_end'], store_tp_obj)
        last_year_this_month_list = calc_sales_data(date_dict['lytm_start'], date_dict['lytm_end'], store_tp_obj)

        sales_list = []
        i = 0
        for store_tp in store_tp_obj:
            sales_list.append({store_tp.cd_nm: [this_month_list[i], last_month_list[i], last_year_this_month_list[i],
                                                last_year_last_month_list[i]]})
            i += 1

        lm_brand_list = calc_brand_sales_data(pdivl_obj, date_dict['lm_start'], date_dict['lm_end'])
        lylm_brand_list = calc_brand_sales_data(pdivl_obj, date_dict['lylm_start'], date_dict['lylm_end'])
        tm_brand_list = calc_brand_sales_data(pdivl_obj, date_dict['tm_start'], date_dict['tm_end'])
        lytm_brand_list = calc_brand_sales_data(pdivl_obj, date_dict['lytm_start'], date_dict['lytm_end'])

        brand_list = []

        i = 0
        for pdivl in pdivl_obj:
            brand_list.append({pdivl[1]: [tm_brand_list[i], lm_brand_list[i], lytm_brand_list[i], lylm_brand_list[i]]})

            i += 1

        context['sales_list'] = sales_list
        context['brand_list'] = brand_list

        context['this_month'] = today.month

        if today.month != 1:
            context['last_month'] = today.month - 1
        else:
            context['last_month'] = today.month

        return context


def get_req_date(today):  # 이번달, 전 달까지 토탈, 작년 이번달, 작년 전 달까지 토탈

    lm_start = datetime(today.year, 1, 1)

    if today.month != 1:
        lm_end = datetime(today.year, today.month, 1) + relativedelta(seconds=-1)
    else:
        lm_end = datetime(today.year, 1, 31)

    lylm_start = lm_start - relativedelta(years=1)
    lylm_end = lm_end - relativedelta(years=1)

    tm_start = datetime(today.year, today.month, 1)
    next_month = datetime(today.year, today.month, 1) + relativedelta(months=1)
    tm_end = next_month - relativedelta(seconds=-1)

    lytm_start = tm_start - relativedelta(years=1)
    lytm_end = tm_end - relativedelta(years=1)

    date_dict = {"lm_start": lm_start, "lm_end": lm_end, "lylm_start": lylm_start, "lylm_end": lylm_end,
                 "tm_start": tm_start, "tm_end": tm_end, "lytm_start": lytm_start, "lytm_end": lytm_end}

    return date_dict


def calc_sales_data(start_date, end_date, store_tp_obj):
    tp_nm_list = []
    tp_id_list = []

    orderlist_obj_list = []
    sales_list = []

    for store_tp in store_tp_obj:
        tp_id_list.append(store_tp.cd_id)
        tp_nm_list.append(store_tp.cd_nm)

        store_obj = Store.objects.values_list('id').filter(store_tp=store_tp.cd_id)

        order_obj = Order.objects.values_list('id').filter(od_dt__range=[start_date, end_date], store_no__in=store_obj)

        orderlist_obj_list.append(Orderlist.objects.filter(od_no__in=order_obj))

    i = 0
    for order_list in orderlist_obj_list:
        price = 0
        for order in order_list:
            price += order.price * order.quantity
            price -= order.dis_price

        sales_list.append(price)
        i += 1

    return sales_list


def calc_brand_sales_data(pdivl_obj, start_date, end_date):
    brand_sales_list = []

    for pdivl in pdivl_obj:
        pdivm_obj = CommonCode.objects.values_list('cd_id').filter(up_cd_id__in=pdivl)
        pdivs_obj = CommonCode.objects.values_list('cd_id').filter(up_cd_id__in=pdivm_obj)

        product_obj = Product.objects.filter(cd_id__in=pdivs_obj)

        order_id_obj = Order.objects.values_list('id').filter(od_dt__range=[start_date, end_date])
        orderlist_obj = Orderlist.objects.filter(od_no__in=order_id_obj, pd_no__in=product_obj)

        price = 0
        for orderlist in orderlist_obj:
            price += orderlist.price * orderlist.quantity

        brand_sales_list.append({pdivl[1]: price})

    return brand_sales_list


def monthly_sales_chart(request):
    today = datetime.today()

    labels = []
    data = []

    for i in range(1, 13):
        start = datetime(today.year, i, 1)
        end = datetime(today.year, i, 1) + relativedelta(months=1) - relativedelta(seconds=1)

        order_id_list = Order.objects.values('id').filter(od_dt__range=[start, end])

        orderlist_obj = Orderlist.objects.values('price', 'quantity', 'dis_price').filter(od_no__in=order_id_list)

        price = 0
        for orderlist in orderlist_obj:
            price += (orderlist['price'] * orderlist['quantity']) - orderlist['dis_price']

        labels.append(str(i) + "월")
        data.append(price)

    return JsonResponse(data={
        'labels': labels,
        'data': data,
    })


def brand_sales_chart(request):
    today = datetime.today()

    labels = []
    data = []

    start = datetime(today.year, 1, 1)
    end = datetime(today.year, 12, 31)

    pdivl_obj = CommonCode.objects.values_list('cd_id', 'cd_nm').filter(g_cd_id='PDIVL')

    for pdivl in pdivl_obj:
        pdivm_obj = CommonCode.objects.values_list('cd_id').filter(up_cd_id__in=pdivl)
        pdivs_obj = CommonCode.objects.values_list('cd_id').filter(up_cd_id__in=pdivm_obj)

        product_obj = Product.objects.filter(cd_id__in=pdivs_obj)

        order_id_obj = Order.objects.values_list('id').filter(od_dt__range=[start, end])
        orderlist_obj = Orderlist.objects.filter(od_no__in=order_id_obj, pd_no__in=product_obj)

        labels.append(pdivl[1])
        data.append(len(orderlist_obj))

    return JsonResponse(data={
        'labels': labels,
        'data': data,
    })


class AccountCreateView(CreateView):
    model = User
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
