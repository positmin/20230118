from django.db import models

from django.utils.timezone import now

from customer.models import Customer
from product.models import Product
from store.models import Store


class Order(models.Model):
    od_dt = models.DateTimeField(db_column='od_dt', default=now)
    od_div = models.CharField(db_column='od_div', max_length=20)
    pos_sales = models.IntegerField(db_column='pos_sales', default=0)
    factory_sales = models.IntegerField(db_column='factory_sales', default=0)
    note = models.CharField(db_column='note', max_length=200, default='')
    cust_no = models.ForeignKey(Customer, db_column='cust_no', on_delete=models.DO_NOTHING)
    store_no = models.ForeignKey(Store, db_column='store_no', on_delete=models.DO_NOTHING)
    register_id = models.CharField(db_column='register_id', max_length=20, default='anonymous')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)

    class Meta:
        db_table = 'order'
