from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from customer.models import Customer
from order.models import Order
from store.models import Store


class OrderList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Order


class OrderDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Order
    fields = ['od_dt', 'od_div', 'note', 'pos_sales', 'factory_sales', 'cust_no', 'store_no']


class OrderCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Order
    success_url = reverse_lazy('order:order_list')
    fields = ['od_dt', 'od_div', 'note', 'pos_sales', 'factory_sales', 'cust_no', 'store_no']


class OrderUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Order
    success_url = reverse_lazy('order:order_list')
    fields = ['od_dt', 'od_div', 'note', 'pos_sales', 'factory_sales', 'cust_no', 'store_no']


class OrderDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Order
    success_url = reverse_lazy('order:order_list')
    fields = ['od_dt', 'od_div', 'note', 'pos_sales', 'factory_sales', 'cust_no', 'store_no']


class StorePopup(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Store
    template_name = 'order/store_popup.html'


class CustomerPopup(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = Customer
    template_name = 'order/customer_popup.html'
