from django.urls import path

from order import views

app_name = 'order'

urlpatterns = [
    path('', views.OrderList.as_view(), name='order_list'),
    path('detail/<int:pk>', views.OrderDetail.as_view(), name='order_detail'),
    path('form', views.OrderCreate.as_view(), name='order_form'),
    path('edit/<int:pk>)', views.OrderUpdate.as_view(), name='order_edit'),
    path('delete/<int:pk>)', views.OrderDelete.as_view(), name='order_delete'),
    path('storePopup', views.StorePopup.as_view(), name='store_popup'),
    path('customerPopup', views.CustomerPopup.as_view(), name='customer_popup'),

]
