from django.urls import path

from common import views

app_name = 'commoncode'

urlpatterns = [
    path('', views.CommonCodeList.as_view(), name='common_code_list'),
    path('detail/<str:pk>', views.CommonCodeDetail.as_view(), name='common_code_detail'),
    path('form', views.CommonCodeCreate.as_view(), name='common_code_form'),
    path('edit/<str:pk>)', views.CommonCodeUpdate.as_view(), name='common_code_edit'),
    path('delete/<str:pk>)', views.CommonCodeDelete.as_view(), name='common_code_delete'),
    path('popup', views.CommonCodePopupList.as_view(), name='common_code_popup_list'),

    path('group', views.GroupCodeList.as_view(), name='group_code_list'),
    path('groupDetail/<str:pk>', views.GroupCodeDetail.as_view(), name='group_code_detail'),
    path('groupForm', views.GroupCodeCreate.as_view(), name='group_code_form'),
    path('groupEdit/<str:pk>', views.GroupCodeUpdate.as_view(), name='group_code_edit'),
    path('groupDelete/<str:pk>', views.GroupCodeDelete.as_view(), name='group_code_delete'),
    path('groupPopup', views.GroupCodePopupList.as_view(), name='group_code_popup_list'),

]


