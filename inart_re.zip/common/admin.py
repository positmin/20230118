from django.contrib import admin

from common.models import CommonCode

admin.site.register(CommonCode)
