from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.models import User
from django.forms import forms
from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import CommonCode
from .models import GroupCode


class CommonCodeList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = CommonCode


class CommonCodePopupList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = CommonCode
    template_name = 'common/commoncodepopup_list.html'


class CommonCodeDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = CommonCode
    fields = ['cd_id', 'cd_nm', 'up_cd_id', 'g_cd_id']


class CommonCodeCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = CommonCode
    success_url = reverse_lazy('commoncode:common_code_list')
    fields = ['cd_id', 'cd_nm', 'up_cd_id', 'g_cd_id', 'register_id']

    def get_form(self, form_class=None):
        form = super(CommonCodeCreate, self).get_form(form_class)
        form.fields['up_cd_id'].required = False

        return form


class CommonCodeUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = CommonCode
    success_url = reverse_lazy('commoncode:common_code_list')
    fields = ['cd_id', 'cd_nm', 'up_cd_id', 'g_cd_id', 'register_id']

    def get_form(self, form_class=None):
        form = super(CommonCodeUpdate, self).get_form(form_class)
        form.fields['up_cd_id'].required = False

        return form


class CommonCodeDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = CommonCode
    success_url = reverse_lazy('commoncode:common_code_list')


class GroupCodeList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = GroupCode


class GroupCodeDetail(LoginRequiredMixin, DetailView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = GroupCode
    fields = ['g_cd_id', 'g_cd_nm']


class GroupCodeCreate(LoginRequiredMixin, CreateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = GroupCode
    success_url = reverse_lazy('commoncode:group_code_list')
    fields = ['g_cd_id', 'g_cd_nm']


class GroupCodeUpdate(LoginRequiredMixin, UpdateView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = GroupCode
    success_url = reverse_lazy('commoncode:group_code_list')
    fields = ['g_cd_id', 'g_cd_nm']


class GroupCodeDelete(LoginRequiredMixin, DeleteView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = GroupCode
    success_url = reverse_lazy('commoncode:group_code_list')


class GroupCodePopupList(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'

    model = GroupCode
    template_name = 'common/groupcodepopup_list.html'
