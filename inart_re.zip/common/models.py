from django.db import models
from django.utils.timezone import now


class GroupCode(models.Model):
    g_cd_id = models.CharField(db_column='g_cd_id', max_length=5, primary_key=True, default='')
    g_cd_nm = models.CharField(db_column='g_cd_nm', max_length=20, default='')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)
    register_id = models.CharField(db_column='register_id', max_length=10, default='anonymous')

    class Meta:
        db_table = 'group_code'


class CommonCode(models.Model):
    cd_id = models.CharField(db_column='cd_id', max_length=5, primary_key=True, default='')
    cd_nm = models.CharField(db_column='cd_nm', max_length=20, default='')
    up_cd_id = models.CharField(db_column='up_cd_id', max_length=10,  default='')
    g_cd_id = models.ForeignKey(GroupCode, db_column='g_cd_id', on_delete=models.DO_NOTHING, default='')
    regist_dt = models.DateTimeField(db_column='regist_dt', default=now)
    register_id = models.CharField(db_column='register_id', max_length=10, default='anonymous')

    class Meta:
        db_table = 'common_code'
